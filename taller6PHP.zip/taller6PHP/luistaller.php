<!DOCTYPE html>
<html>
<body>

<?php
class robot{

//atributos
var $movilidad;
var $autonomia;
var $capacidad_carga;
var $programabilidad;

//constructor

function robot($m, $a, $c, $p){
$this->movilidad=$b;
$this->autonomia=$a;
$this->capacidad_carga=$c;
$this->programabilidad=$p;
}

//metodo

function caminar(){
echo "el robot esta caminando:".$this->movilidad;
}

function auto(){
echo "el robot tiene mucha autonomia:".$this->autonomia;
}

function progra(){
echo "el robot se puede reprogramar:".$this->programabilidad;
}


}
$objeto = new robot("comer ","si ","20 ","30 ");
$objeto->caminar();
$objeto->auto();
$objeto->progra();
?> 

</body>
</html>
