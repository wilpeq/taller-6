<!DOCTYPE html>
<html>
<body>

<?php

class Oso{
//atributos
var $peludo;
var $fuerte;
var $comelon;
var $naranja;

 function Oso ($p, $f,$c,$n){
 $this->peludo =$p;
 $this->fuerte =$f;
 $this->comelon =$c;
 $this->naranja =$n;
 }
 //Metodo
 function Comiendo(){
 
 echo "El oso esta : ".$this->peludo.$this->fuerte.$this->comelon.$this->naranja;
 }
}
$objeto = new Oso("peludo ","fuerte ","comelon ","naranja ");
$objeto->Comiendo();
?> 
</body>
</html>